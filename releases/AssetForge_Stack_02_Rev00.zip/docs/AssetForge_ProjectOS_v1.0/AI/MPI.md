# MPI
Master Prompt Interface.
